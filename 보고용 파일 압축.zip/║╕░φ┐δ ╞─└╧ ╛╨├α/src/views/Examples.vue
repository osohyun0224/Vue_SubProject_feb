<template>
<RenderFunction :level="2" />
</template>
<script>
import RenderFunction from './RenderFunction';
export default {
  components: {RenderFunction}
}
</script>